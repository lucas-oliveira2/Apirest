package repository;

public class BoardRepository {
    
}
