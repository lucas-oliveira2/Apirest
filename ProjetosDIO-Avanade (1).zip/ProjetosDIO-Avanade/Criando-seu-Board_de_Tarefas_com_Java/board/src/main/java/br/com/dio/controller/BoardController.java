package controller;

public class BoardController {
    
}
