package repository;

public class CardRepository {
    
}
