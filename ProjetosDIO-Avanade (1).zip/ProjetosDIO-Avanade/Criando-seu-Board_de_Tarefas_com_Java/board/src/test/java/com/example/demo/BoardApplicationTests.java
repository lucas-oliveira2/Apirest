package br.com.dio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardApplicationTests {

    @Test
    void contextLoads() {
        // Teste básico para verificar se o contexto da aplicação carrega corretamente
    }
}
