export const dataFake = [
    {
        "id": '1',
        "photo": 'https://storage.googleapis.com/twg-content/original_images/travel-content-takes-off-on-youtube_articles_lg.png',
        "title": "Let's start the journey",
        "description": 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam pulvinar rutrum rhoncus. Aliquam congue, metus non fringilla eleifend, purus felis feugiat arcu, non sagittis quam nibh vitae est. Etiam turpis urna, tincidunt eget sem in, hendrerit rutrum ligula. Morbi finibus quam ex, ut luctus libero ornare ut. In iaculis maximus dui, id bibendum ipsum tincidunt et. Nulla volutpat, nunc quis ultricies eleifend, urna lectus laoreet ipsum, a auctor elit ligula a erat. Proin in orci eget mi tristique fringilla.'
    },
    {
        "id": '2',
        "photo": 'https://cdn.pixabay.com/photo/2019/09/22/04/18/path-4495045_1280.jpg',
        "title": 'Dare to live the life',
        "description": 'Ut id justo nec mi tempus gravida. Integer nec vestibulum turpis. Praesent sed porttitor enim. Nunc finibus aliquet tristique. Suspendisse eleifend ut massa in feugiat. Praesent a sem eu tellus eleifend rhoncus. Maecenas et consequat mi. Nam id tellus non ante egestas gravida. Nullam ornare, odio ac posuere pulvinar, est ligula tempus eros, nec rutrum nisl tortor ac nisl. Sed porttitor mi eget turpis tristique dapibus. Curabitur eu nibh lectus. Aenean elementum nibh id vestibulum bibendum. Fusce ut tortor non massa euismod euismod a eget erat. Etiam ut erat eu odio ultrices venenatis maximus quis quam.'
    },
    {
        "id": '3',
        "photo": 'https://discover-your-south-america.com/blog/wp-content/uploads/2019/04/Pantanal-Wetlands.jpg',
        "title": 'Collect moments',
        "description": 'Etiam ac elit vel orci condimentum aliquam sed non purus. Aliquam tempus arcu in felis elementum faucibus. Suspendisse lacinia dictum odio id accumsan. Praesent nec hendrerit mauris. Ut id elit ac dolor feugiat vestibulum sed sed quam. Duis a rutrum tortor. Curabitur aliquam metus in mollis fermentum. Nam finibus quam sit amet porttitor sollicitudin. Mauris vel nisl sit amet urna scelerisque rhoncus. Suspendisse lectus mi, euismod vel convallis ut, volutpat nec arcu. Integer dictum ultricies risus nec dignissim.'
    },
    {
        "id": '4',
        "photo": 'https://thumbs.dreamstime.com/b/spring-summer-landscape-blue-sky-clouds-river-boat-green-trees-narew-countryside-grass-poland-water-leaves-58070004.jpg',
        "title": 'Some beautiful place to get lost',
        "description": 'Mauris quis faucibus tellus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Integer sed purus pulvinar, dignissim ipsum nec, tempus libero. Sed at quam arcu. Vestibulum et nisl sem. In laoreet tellus quam, at eleifend leo consequat non. Donec posuere mattis purus in pretium. In hac habitasse platea dictumst. Quisque ac iaculis libero. Morbi purus quam, tristique nec congue eu, pharetra.'
    }
]
