import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-title',
  templateUrl: './menu-title.component.html',
  styleUrls: ['./menu-title.component.scss', './menu-title.responsive.component.scss']
})
export class MenuTitleComponent {

}
