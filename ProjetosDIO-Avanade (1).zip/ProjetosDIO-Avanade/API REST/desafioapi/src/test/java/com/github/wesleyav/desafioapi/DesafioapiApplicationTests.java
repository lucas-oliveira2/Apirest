package com.github.wesleyav.desafioapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
