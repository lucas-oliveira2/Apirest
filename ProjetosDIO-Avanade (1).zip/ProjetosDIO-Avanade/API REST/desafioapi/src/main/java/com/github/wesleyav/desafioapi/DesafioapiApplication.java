package com.github.wesleyav.desafioapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioapiApplication.class, args);
	}

}
