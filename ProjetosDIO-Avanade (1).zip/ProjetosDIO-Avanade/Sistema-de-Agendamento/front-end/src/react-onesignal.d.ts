// declare module "react-onesignal" {
//   export interface IOneSignal {
//     init(config: any): void;
//     on(eventName: string, callback: Function): void;
//     getUserId(callback: (id: string) => void): void;
//   }

//   const OneSignal: IOneSignal;
//   export default OneSignal;
// }