export interface ChangeEvent {
  current: {
    id: string | null | undefined;
  };
}