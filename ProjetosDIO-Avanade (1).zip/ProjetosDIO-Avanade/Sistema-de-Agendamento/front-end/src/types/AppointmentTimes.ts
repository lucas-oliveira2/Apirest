export type BookTime = {
  hour: string;
  totalDuration: number;
};
