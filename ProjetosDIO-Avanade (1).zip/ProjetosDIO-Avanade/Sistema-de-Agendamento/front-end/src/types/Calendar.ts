export type DateList = {
  dayName: string;
  date: string;
};