export type DayOffDb = {
  dayOffId?: number;
  barberId: number;
  dayOff: string;
  time: string;
}; 