export type Cancellation = {
  cancellationId: number;
  dateSchedule: string;
  dateCancellation: Date;
  userId: number;
  eventId: string;
};