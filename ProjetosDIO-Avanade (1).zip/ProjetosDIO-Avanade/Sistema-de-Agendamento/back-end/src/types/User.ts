export type User = {
  userId: number;
  name: string;
  phone: string;
  deviceId: string | null | undefined;
};