export type BarberUser = {
  barberId: number;
  name: string;
  email: string;
  password: string;
};