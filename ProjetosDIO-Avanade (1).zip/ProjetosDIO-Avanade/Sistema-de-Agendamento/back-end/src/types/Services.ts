export type Service = {
  serviceId: number;
  service: string | string[];
  price: number;
  duration: number;
};