export type ScheduleService = {
  id: number;
  scheduleId: number;
  serviceId: number;
};